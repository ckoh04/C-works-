#include "Card.hpp"  
#include <iostream>  
#include <stdio.h>
#include <stdlib.h>
  
using namespace std;  
  
  
Card::Card(int number)  
{  
  this->number = number;  
}  
  
void Card::show()  
{  
  int pattern;  
  int cardnumber;  
  
  pattern = number / 13;  
  cardnumber = number % 13;  
  
  
  switch(pattern) {  
  case 0:  
    cout << "SPADE" ;  
    break;  
  case 1:  
    cout <<"DIAMOND";  
    break;  
  case 2:  
    cout <<"CLOVER";  
    break;  
  case 3:  
    cout <<"HEART";  
    break;  
  default:  
    break;  
  }  
  
  if (cardnumber > 1 && cardnumber < 11 ) {  
    cout << cardnumber << " ";  
  }else {  
    switch (cardnumber) {  
    case 0:  
      cout << "K " ;  
      break;  
    case 1:  
      cout << "A " ;  
      break;  
    case 11:  
      cout <<"J ";  
      break;  
    case 12:  
      cout << "Q ";  
      break;  
    }  
  }  
}  
  


