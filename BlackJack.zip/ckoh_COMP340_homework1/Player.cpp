#include "Player.hpp"

Player::Player() {  
}  
  
Player::Player(int _Point) {  
  Point = _Point;  
}  
  
Player::Player(std::string _name, int _Point):Person(_name) {  
  Point = _Point;  
}  
  
Player::Player(std::string name, int age, int point):Person(name, age){  
  this->Point = Point;  
}  
  
int Player::getPoint() const {  
  return Point;  
}  
  
void Player::setPoint(int point) {  
  this->Point = point;  
  
}  
  
void Player::changePoint(int point) {  
  this->Point += Point;  
}  
  
int Player::clearCard()  
{  
  myCard.clear();  
  return 0;  
}  
  
int Player::addCard(Card add)  
{  
  myCard.push_back(add);  
  return 0;  
}  
  
void Player::showMyCard()  
{  
  int temp = 0;  
  for ( int i = 0 ; i < myCard.size(); i ++ )   
  {  
    myCard[i].show();  
    temp = myCardPoint();  
  }  
  cout << " " << temp;  
}  
  
//Not considering about Ace   
int Player::myCardPoint()  
{  
  int ret = 0;   
  for ( int i = 0 ; i < myCard.size(); i ++ )   
  {  
    int temp =  myCard[i].CardPoint();  
  
    if ( temp > 10)   
    {  
      ret = ret + 10;  
    }  
    else   
    {  
      ret = ret + temp;  
    }  
  }  
  
  //Definition of Ace (1/11) 
  for ( int j = 0; j < myCard.size(); j++ )  
  {  
    int temp2 = myCard[j].CardPoint();  
    if ( temp2== 1)  
    {  
      int temp3 = 0;  
      for(int k = 0; k < j; k++)  
      {  
        temp3 = temp3 + myCard[k].CardPoint();  
      }  
      if(temp3 < 11)  
      {  
        ret = ret + 10;  
      }  
    }  
  }  
  
  return ret;  
  
}  
  
  
bool Player::playCard(DeckofCards* deck) {  
  bool ret = false;  //bust;  
  
  int inputNumber;  
    
  while (1) {  
    cout << getName() << " : ";  
      
    showMyCard();  
    cout << "\n";  
  
    if ( myCardPoint() > 21 ) {  
        
      cout << "BURST..." <<endl;  
      //Point deduction
      return false;  
    }  
      
    cout << getName() << ". ";  
    cout <<" Do you want more cards? ( PRESS 1 to recieve.) " ;  
    cin >> inputNumber;  
    if ( inputNumber != 1 )  
      break;  
  
      
    addCard( deck->getCard() );  
    //Recieve one card
      
      
  }  
  showMyCard();  
  return true;  
}  

