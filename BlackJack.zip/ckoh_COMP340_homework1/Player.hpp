#ifndef PLAYER_HPP
#define PLAYER_HPP

#include "Person.hpp"
#include "DeckofCards.hpp"

//stores information of players in the game 
class Player:public Person{  //inherit from person  
private:  
  int Point;        //point used to bet (initialize) 
  vector <Card> myCard;  //card you have 
    
public:  
  Player();          
  Player(int Point);  
  Player(string name, int Point);  
  Player(string name, int age, int Point);  
  
  int getPoint() const;    //check how much point you have  
  void setPoint(int point);  //set point   
  void changePoint(int point);//amend point in case of changes  
  
  bool playCard(DeckofCards* deck);  //when bust (over 21) return FALSE; 
  int addCard(Card); // get one more card  
  void showMyCard(); // show card  
  int myCardPoint(); // show card point    
  int clearCard();  
}; 
#endif 
