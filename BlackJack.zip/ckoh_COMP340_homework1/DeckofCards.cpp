#include "DeckofCards.hpp"
#include <iostream>
#include <stdio.h
#include <stdlib.h>  

DeckofCards::DeckofCards(){  
  srand(time(NULL));  
  init();  
}  
  
void DeckofCards::shuffle(){  
  for ( int i = 0 ; i < 100 ; i ++) {  
    Card temp;  
    int left;  
    int right;  
      
    left = rand() % CARDNUMBER;  
    right = rand() % CARDNUMBER;  
    temp = number[left];  
    number[left]=number[right];  
    number[right]=temp;  
  }  
}  
  
Card DeckofCards::getCard(){  
  Card card;  
  if (number.size() >= 1) {  
      
    card = number[number.size() -1];  
    number.pop_back();  
  }  
  return card;  
}  
  
void DeckofCards::init() {  
  number.clear();  
  for ( int i = 0 ; i < 52; i ++ ){   
    number.push_back(i+1);   
  }  
}  
