#ifndef DECKOFCARDS_HPP
#define DECKOFCARDS_HPP  

#include "Card.hpp"

class DeckofCards{  
private:  
//  vector<int> number; //52 cards 
  vector<Card> number; //52 cards  
public:  
  
  DeckofCards();  
    
  void init();  
    
  void shuffle();  
  
  Card getCard();  
};  
  
#endif 
