#ifndef CARD_HPP
#define CARD_HPP  

    
#include <vector>  
#include <ctime>  
#include <string>  
#include <iostream>  
 

const int CARDNUMBER = 52;  
   
class Card{  
private:   
  std::string SPADE;
  std::string HEART; 
  std::string DIAMOND;
  std::string CLOVER;
    
  int number;  
public:  
  Card(int number); //put numbers into card
  void show(); //show card
  Card() {  
    number = 51;  
    SPADE = "S";
    HEART = "H";
    DIAMOND = "D";  
    CLOVER ="C";  
  }  
  int CardPoint()   
  {  
    int temp = 0;  
    if(number%13 == 0)  
    {  
      temp = temp + 10;  
    }  
  
    else if( number%13  < 10)  
    {  
      temp = temp + number%13 ;  
    }  
    else  
    {  
      temp = temp + 10;  
    }  
      
    return (temp);  
}
};

#endif 



