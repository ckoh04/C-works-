#include "Card.hpp"  
#include "Person.hpp"  
#include "Player.hpp"
#include "DeckofCards.hpp"
#include <iostream>  
#include <string>  
  
using namespace std;  
  
int main()   
{  
    
  //create an oject of card using the Card class
  DeckofCards Deck;  
  // shuffle the card deck created    
  Deck.shuffle();  
  
  
  int playerCount;  
  cout << " How many people are playing? ";  
  cin >> playerCount;  
  
  Player* gamer = new Player[playerCount];  
    
  //set dealer   
  Player direr("Dealer", 20, 50000);  
  
  cout << "Please enter information for the players: " <<endl;  
    
  for ( int i = 0 ; i < playerCount; i ++ )   
  {  
    string inputName;  
    cout <<endl<< i+1 << "First person up is:  " ;  
    cin >> inputName;  
    gamer[i].setName(inputName);  
  
    int inputAge;  
    cout << inputName << " What is your age? ";  
    cin >> inputAge;  
    gamer[i].setAge(inputAge);  
  
    int point;  
    cout << inputName << "What is your point? ";  
    cin >>point;  
    gamer[i].setPoint(point);  
  }  
  cout << " Thank you for the input. "<< endl <<endl;  
  
  cout << " Check your input. " << endl;  
  cout << " #################################### " << endl;  
    
  //for (int  i = 0 ; i < playerCount; i ++ ) {  
  int i;  
  for (  i = 0 ; i < playerCount; i ++ )   
  {  
    cout << gamer[i].getName()<< ", age : "  << gamer[i].getAge() << ", Point " << gamer[i].getPoint() <<endl;  
  }  
  cout << " #################################### " << endl;  
  
  cout << " START " << endl<<endl;  
    
  //introduction to the game  
  cout << "Rules: " << endl;  
  cout << "Players recieve two or more cards from the dealer as wanted." << endl;  
  cout << "If your card does exceed the number of 21 and you have more points, you win." <<endl;  
  cout << "There are 13 types of cards, and 10,J,Q,K worth 10 points." << endl;  
  cout << "Ace card will worth 11 points if you have 10 or less cards, but it will worth 1 after you have more than 10 cards " <<endl;   
  cout << "-----------------------------------------------------------------------" <<endl;  
  
  int end = 0;  
  vector<int> beting;  
  
  while(end == 0)  
  {  
    //information for player's point 
    for( i = 0; i < playerCount ; i ++ )  
    {  
      cout << gamer[i].getName() << " Your remaining point is: ";  
      cout << gamer[i].getPoint() << endl;  
    }  
  
    //point bettting  
    for( i = 0; i < playerCount ; i ++ )  
    {  
      int temp = 0;  
      cout << gamer[i].getName() << " How much point do you want to bet? ";  
      cin >> temp;  
      if(temp > gamer[i].getPoint())  
      {  
        temp = gamer[i].getPoint();  
      }  
      else if(temp > 50)  
      {  
        cout << "Maximum betting point is 50." << endl;  
        temp = 50;  
      }  
      else  
      {  
        temp = 0 + temp;  
      }  
      beting.push_back(temp);              
    }  
      
    //recieve first card
    for ( i = 0 ; i <playerCount; i ++ )   
    {  
      Card temp = Deck.getCard();  
      gamer[i].addCard(temp);  
      cout << gamer[i].getName() << " : ";  
      gamer[i].showMyCard();  
      cout << "\n";  
    }  
    //first card for dealer  
    Card temp = Deck.getCard();  
    direr.addCard(temp);  
    cout << direr.getName() << " : ";  
    direr.showMyCard();  
    cout << "\n";  
  
  
    //second card for player 
    for ( i = 0 ; i <playerCount; i ++ )   
    {  
      Card temp = Deck.getCard();  
      gamer[i].addCard(temp);  
      cout << gamer[i].getName() << " : ";  
      gamer[i].showMyCard();  
      cout << "\n";  
    }  
      
  
    //second card for dealer   
    cout << direr.getName() << " : ";  
    direr.showMyCard();  
    cout << "\n";  
    Card temp2 = Deck.getCard();  
    direr.addCard(temp2);    
      
    // last card for dealer 
    if(direr.myCardPoint() < 16)  
    {  
      while(direr.myCardPoint() < 16)  
      {  
        Card temp3 = Deck.getCard();  
        direr.addCard(temp3);  
      }  
    }  
  
  
    //game starts 
    for ( i = 0 ; i <playerCount; i ++ )   
    {  
      gamer[i].playCard(&Deck);  
      cout << "\n";  
    }  
      
      
  
    if(direr.myCardPoint() > 21)  
    {  
      cout << " Dealer BURST..." << endl;  
      int winerpoint = 0;  
      for ( i = 0 ; i <playerCount; i ++ )   
      {  
        if(gamer[i].myCardPoint() > winerpoint)  
        {  
          winerpoint = gamer[i].myCardPoint();  
        }  
      }  
  
      for ( i = 0 ; i < playerCount; i ++ )   
      {  
        if(gamer[i].myCardPoint() == winerpoint && gamer[i].myCardPoint() < 21)  
        {  
          cout << gamer[i].getName() << " YOU WIN. " << endl;  
          gamer[i].setPoint( gamer[i].getPoint() + beting[i] );  
        }  
        else  
        {  
          gamer[i].setPoint( gamer[i].getPoint() - beting[i] );  
        }  
      }  
    }  
      
      
    else  
    {  
      cout << direr.getName() << " : ";  
      direr.showMyCard();  
      cout << endl;  
  
      for ( i = 0 ; i <playerCount; i ++ )   
      {  
        cout << gamer[i].getName() << " : ";  
        gamer[i].showMyCard();  
        cout << "\n";  
      }  
        
      int winerpoint = direr.myCardPoint();  
  
      for ( i = 0 ; i <playerCount; i ++ )   
      {  
        if(gamer[i].myCardPoint() > winerpoint)  
        {  
          if(gamer[i].myCardPoint() > 21);  
          else  
          {  
            winerpoint = gamer[i].myCardPoint();  
          }  
        }  
      }  
  
        
  
      for ( i = 0 ; i < playerCount; i ++ )   
      {  
        if(winerpoint == direr.myCardPoint())  
        {  
          cout << "DEALER WINS. " << endl;  
          gamer[i].setPoint( gamer[i].getPoint() - beting[i] );  
        }  
        else if(gamer[i].myCardPoint() == winerpoint)  
        {  
          cout << gamer[i].getName() << "YOU WIN. " << endl;  
          gamer[i].setPoint( gamer[i].getPoint() + beting[i] );  
        }  
        else  
        {  
          gamer[i].setPoint( gamer[i].getPoint() - beting[i] );  
        }  
      }  
    }  
      
    
      
    cout << " Do you want to continue?  ( PRESS 0 to continue )";  
    cin >> end;  
    direr.clearCard();  
    for( i = 0; i < playerCount; i++)  
    {  
      gamer[i].clearCard();  
    }  
    beting.clear();  
  }  
  cout << " Was the game fun?: " << endl<<endl;  
  
  
  
  cout <<endl<< " #################################### " << endl;    
  //for (int  i = 0 ; i < playerCount; i ++ ) {  
  for (  i = 0 ; i < playerCount; i ++ )   
  {  
    cout << gamer[i].getName()<< ", age : "  << gamer[i].getAge() << ", Point " << gamer[i].getPoint() <<endl;  
  }  
  cout << " #################################### " << endl;  
  return 0;  
}  



