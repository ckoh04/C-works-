#ifndef PERSON_HPP
#define PERSON_HPP

#include "Card.hpp"  
#include <string>  

  
//stores information of person in the game 
class Person{  
private:  
  std::string name;  // name of person  
  int age;    //age of person 
public:  
  Person();    //create person without name or age first  
  Person(std::string name);  //create person with only name 
  Person(std::string name, int age);  
    
  std::string getName() const;    //return person's name 
  int getAge() const;      //return person's age    
  void setName(std::string name);  //set person's name  
  void setAge( int age);    //set person's age   
};  
#endif 


