#include "Person.hpp"  
  


Person::Person(){  
  age = -1;  
}  
  
Person::Person(std::string name){  
  this->name = name;  
  
}  
  
  
Person::Person(std::string name, int age){  
  this->age = age;  
  this->name = name;    
}  
  
std::string Person::getName() const  
{  
  return name;  
}  
  
void Person::setName(std::string name)  
{  
  this->name = name;  
}  
  
int Person::getAge() const  
{  
  return age;  
}  
  
void Person::setAge(int age)  
{  
  this->age = age;  
}  
